package component2;

//creating a currency class whose attributes are string currency, double conversion rate, string symbol
public class Currency {
	private String currency; 
	private double conversionRate;
	private String symbol;
	
	//constructor of currency class with three parameters
	public Currency(String currency,double convRate,String symbol) {
		this.currency = currency;
		this.conversionRate = convRate;
		this.symbol = symbol;
	}
	
	//creating all setters and getters of all three attributes
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public double getConvRate() {
		return conversionRate;
	}
	public void setConvRate(double convRate) {
		this.conversionRate = convRate;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
}
