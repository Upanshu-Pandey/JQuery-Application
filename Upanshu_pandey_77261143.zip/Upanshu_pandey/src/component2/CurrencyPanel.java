package component2;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Scanner;

import javax.swing.*;


@SuppressWarnings("serial")
public class CurrencyPanel extends JPanel{
	//Declaring all components and other variables needed here as attributes
	private JTextField inputField;
	private JLabel inputLabel;
	private JLabel conversionCount;
	private int count =0;
	private JLabel resultLabel;
	private JComboBox<String> currencyList;
	private JButton convert;
	private JButton clear;
	private JCheckBox reverse;
	private ArrayList<Currency> currencydata = new ArrayList<Currency>(); //data type of this array list is Currency class
	private File file;
	String errors="";
	
	//load file method where the file is chosen with the help of java file chooser component and checking if there is valid data 
	//stores valid data into the array list otherwise stores an error message in a variable .If error variable is not empty then displays
	//all error message in a dialog box
	public void loadFile(File file) {
		try {
			errors = "";
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF8"));
			Scanner scan = new Scanner(in);
			int recordNo =1;
			while(scan.hasNextLine()) {
				String lineToread = scan.nextLine();
				String[] temp = lineToread.split(",");
				
				if(temp.length==3) {
					if(temp[0].trim().isEmpty()) {
						errors += "Line number "+recordNo +" has no currency name\n";
					}
					else if(temp[1].trim().isEmpty()) {
						errors += "Line number " + recordNo + " has no conversion rate\n";
					}
					else if(temp[2].trim().isEmpty()) {
						errors += "Line number " + recordNo + " has no symbol \n";
					}
					else {
						try {
							double convRate = Double.parseDouble(temp[1].trim());
							currencydata.add(new Currency(temp[0].trim(),convRate,temp[2].trim()));
						}catch(NumberFormatException e) {
							errors += "Line number " + recordNo + " has wrong number format for conversion rate \n";
						}
					}
				}
				else {
					errors += "Line number " + recordNo+ " does not have enough delimiters\n";
				}
				
				
				recordNo++;	
			}
			scan.close();
			
			if(!errors.isEmpty()) {
				JOptionPane.showMessageDialog(null, errors);
			}
			
		}catch(IOException e) {
			JOptionPane.showMessageDialog(new JFrame(), "No file found","file error", JOptionPane.WARNING_MESSAGE);
		}
	}
	
	
	//Currency Panel constructor where all java components are initialised , with their respective tool tips and parameters.
	//action listener used for input field, convert button and clear button to do their desired task.
	//also loading a file at the beginning of the program to populate all currency list items and the conversion rate values for conversion
	public CurrencyPanel(){
		file = new File("text.txt");
		loadFile(file);
		
		inputLabel = new JLabel("Enter amount: ");
		
		inputField = new JTextField(15);
		inputField.setToolTipText("Enter your values here which needs to be converted to another currency");
		inputField.setMaximumSize(new Dimension(220,25));
		
		convert = new JButton("Convert");
		convert.setToolTipText("when pressed converts the value in input field");
		convert.setToolTipText("");
		ConvertListener convList = new ConvertListener();
		convert.addActionListener(convList);
		inputField.addActionListener(convList);
		
		currencyList = new JComboBox<String> ();
		currencyList.setToolTipText("List of currencies available for conversion");
		currencyList.setMaximumSize(new Dimension(220,25));
		for(int i=0;i<currencydata.size();i++) {
			currencyList.addItem(currencydata.get(i).getCurrency());
		}
		
		
		conversionCount = new JLabel("Conversion Count: "+count);
		
		resultLabel = new JLabel("----");
		resultLabel.setToolTipText("converted value is hown here");
		
		clear = new JButton("Clear");
		clear.setToolTipText("press this button to clear all fields");
		ClearListener resetListen = new ClearListener();
		clear.addActionListener(resetListen);
		
		reverse = new JCheckBox("Reverse Conversion");
		reverse.setToolTipText("press this button to reverse the conversion");
		
		//aligning all components to the center of the panel
		currencyList.setAlignmentX(CENTER_ALIGNMENT); 
		inputLabel.setAlignmentX(CENTER_ALIGNMENT);
		inputField.setAlignmentX(CENTER_ALIGNMENT);
		convert.setAlignmentX(CENTER_ALIGNMENT);
		reverse.setAlignmentX(CENTER_ALIGNMENT);
		clear.setAlignmentX(CENTER_ALIGNMENT);
		conversionCount.setAlignmentX(CENTER_ALIGNMENT);
		resultLabel.setAlignmentX(CENTER_ALIGNMENT);
		
		//adding all components to the panel
		add(currencyList);
		add(inputLabel);
		add(inputField);
		add(convert);
		add(reverse);
		add(clear);
		add(conversionCount);
		add(resultLabel);
		
		setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
		setPreferredSize(new Dimension(500,200));
		
	}
	
	//creating a menu bar and adding required menu items and sub items to it
	//using appropriate action listener for all the menu item 
	JMenuBar setUpMenu() {
		JMenuBar menuBar = new JMenuBar();
		
		JMenu fileMenu = new JMenu("File");
		fileMenu.setMnemonic(KeyEvent.VK_F);
		fileMenu.setIcon(new ImageIcon("file.png"));
		
		JMenu help = new JMenu("Help");
		help.setMnemonic(KeyEvent.VK_H);
		help.setIcon(new ImageIcon("help.png"));
		
		JMenuItem exit = new JMenuItem("Exit",KeyEvent.VK_X);
		exit.setIcon(new ImageIcon("exit.png"));
		JMenuItem about = new JMenuItem("About",KeyEvent.VK_A);
		about.setIcon(new ImageIcon("about.png"));
		JMenuItem load = new JMenuItem("Load",KeyEvent.VK_O);
		load.setIcon(new ImageIcon("load.png"));
		
		//stores the selected file using the file chooser if any selected
		load.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent event) {
				JFileChooser chooseFile = new JFileChooser();
				int selected = chooseFile.showOpenDialog(null);
				
				if(selected == JFileChooser.APPROVE_OPTION) {
					currencydata.removeAll(currencydata); // clearing all data before loading another file's data into the array list
					currencyList.removeAllItems();
					file = chooseFile.getSelectedFile();
					loadFile(file);
					
					for(int i=0;i<currencydata.size();i++) {
						currencyList.addItem(currencydata.get(i).getCurrency());
					}
				}else {
					JOptionPane.showMessageDialog(new JFrame(), "No file chose","File Error",JOptionPane.WARNING_MESSAGE);
				}
				
			}
			
		});
		
		exit.addActionListener(e->{
			int exitOrNot = JOptionPane.showConfirmDialog(new JFrame(),"Do you want to exit?","Exit Confirm Box",JOptionPane.YES_NO_OPTION );
			if(exitOrNot == JOptionPane.YES_OPTION) {
				System.exit(0);
			}
		});
		
		about.addActionListener(e->{
			JOptionPane.showMessageDialog(new JFrame(),"About the author","About",JOptionPane.INFORMATION_MESSAGE );
		});
		
		//adding menu's to menu bar
		menuBar.add(fileMenu);
		menuBar.add(help);
		
		//adding sub menu to their respective parent menu 
		fileMenu.add(load);
		fileMenu.add(exit);
		help.add(about);
		
		return menuBar;
	}
	
	//this class's method action performed which is invoked when convert button or input field entered is called
	//here the conversion rate and symbols stored in array list is used to do all the conversion and display the output
	private class ConvertListener implements ActionListener{
		public void actionPerformed(ActionEvent event) {
			int comboSelected = currencyList.getSelectedIndex();
			String temp = inputField.getText();
			try {
				if(temp.isEmpty()) {
					JOptionPane.showMessageDialog(new JFrame(),"Input field is empty","Empty",JOptionPane.WARNING_MESSAGE );
				}
				else {
					double input = Double.parseDouble(temp);
					double resultVal =0;
					double conversionRate=0;
					String symbol="";
					
					for(int i =0;i<currencydata.size();i++) {
						if(comboSelected == i) {
							conversionRate = currencydata.get(i).getConvRate();
							symbol = currencydata.get(i).getSymbol();
							count++;
						}
					}
					
					if(reverse.isSelected()==true) {
						resultVal = input / conversionRate;
						symbol = " \u00A3";
					}
					else {
						resultVal = input* conversionRate;
					}
					
					//using formatter to limit the result's decimal value to two digit 
					@SuppressWarnings("resource")
					Formatter formattedVal = new Formatter();
					formattedVal.format("%.2f", resultVal);
					resultLabel.setText("Result: "+symbol+" "+formattedVal.toString());
					conversionCount.setText("Conversion Count: "+count);
					
				}		
			}catch(NumberFormatException error) {
				JOptionPane.showMessageDialog(new JFrame(),"Input value is non-numeric","Invalid input",JOptionPane.WARNING_MESSAGE );
			}
			
		}
			
	}
	
	
	
	private class ClearListener implements ActionListener{
		public void actionPerformed(ActionEvent event) {
			//clearing all fields when clear button pressed
			resultLabel.setText("---");
			count =0;
			conversionCount.setText("Conversion Count: "+count);
			inputField.setText("");
			currencyList.setSelectedIndex(0);
			reverse.setSelected(false); // un-selecting check box 
		}
	}
}
